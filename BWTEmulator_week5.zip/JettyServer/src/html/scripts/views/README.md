Overview
-----------------------------------------------------
views/: Standard views folder for MVC structure.

TODO: All of the view logic is placed in the DOM and css for now. We may want to
abstract some of this logic as a view.

Files
-----------------------------------------------------
