Overview
-----------------------------------------------------
controllers/: Standard controllers folder for MVC structure.

Files
-----------------------------------------------------
### load.js
  * Loads key parts of our emulator.
    * Adds all slate cells to the DOM.
    * Attaches event listeners to all buttons in the DOM.
  * TODO: some initialization logic should be abstracted into the constuctor for an Emulator model.
