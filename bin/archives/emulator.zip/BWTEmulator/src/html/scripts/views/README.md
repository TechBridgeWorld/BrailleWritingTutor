Overview
-----------------------------------------------------
views/: Standard views folder for MVC structure.

TODO: All of the view logic is placed in the DOM and css for now. We may want to
abstract some of this logic as a view.

Files
-----------------------------------------------------
### Viewer.js (ltray@cmu.edu)
  * Main object controlling app rendering.
  * @TODO: this isn't really used, much of the view logic is baked into
           the css and DOM itself. This should be abstracted into various
           view methods/objects.
