This folder should hold the configuration file for logback, which handles logging of this project.
The current logback.xml is configured to create three different log files.
To modify the configuration, i.e. creating additional loggers or rolling file appenders by date/file length, 
modify the xml file accordingly.

More tutorials and documentations can be found at 
http://logback.qos.ch/
